package software;

public class Skill
{
	String name;
	String ID;
	public Skill(String name,String ID)
	{
		this.name=name;
		this.ID=ID;
	}
}
