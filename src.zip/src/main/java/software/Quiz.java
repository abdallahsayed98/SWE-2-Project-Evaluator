package software;

public class Quiz {
	int Quiz_ID;
	String Quiz_Name;
	public Quiz(int id,String name)
	{
		this.Quiz_ID=id;
		this.Quiz_Name=name;
	}

}
