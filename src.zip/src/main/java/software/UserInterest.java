package software;

import java.util.ArrayList;

public class UserInterest {
	 public int userID;
     public ArrayList<String > interests=new ArrayList<String>();
     public UserInterest(int userID)
     {
    	 this.userID=userID;
     }

}
